import React, { useState } from 'react';
import { AppView, DashboardTab, UserPreferences } from './types';
import { Onboarding } from './components/Onboarding';
import { Visualizer } from './components/Visualizer';
import { Marketplace } from './components/Marketplace';
import { Layout, Eye, ShoppingCart, LogOut, Hexagon } from 'lucide-react';

const App: React.FC = () => {
  const [currentView, setCurrentView] = useState<AppView>(AppView.ONBOARDING);
  const [activeTab, setActiveTab] = useState<DashboardTab>(DashboardTab.VISUALIZER);
  const [userPrefs, setUserPrefs] = useState<UserPreferences | null>(null);

  const handleOnboardingComplete = (prefs: UserPreferences) => {
    setUserPrefs(prefs);
    setCurrentView(AppView.DASHBOARD);
  };

  const handleLogout = () => {
    setUserPrefs(null);
    setCurrentView(AppView.ONBOARDING);
    setActiveTab(DashboardTab.VISUALIZER);
  };

  if (currentView === AppView.ONBOARDING) {
    return <Onboarding onComplete={handleOnboardingComplete} />;
  }

  return (
    <div className="min-h-screen bg-warm-50 flex flex-col md:flex-row">
      {/* Sidebar Navigation */}
      <aside className="w-full md:w-72 bg-white border-r border-gray-100 flex flex-col fixed md:relative bottom-0 z-50 md:z-0 md:h-screen shadow-2xl md:shadow-none">
        <div className="p-8 hidden md:block border-b border-gray-50">
          <div className="flex items-center gap-2 mb-2">
            <div className="p-2 bg-brand-50 rounded-lg text-brand-600 shadow-sm">
               <Hexagon className="w-6 h-6" />
            </div>
            <h1 className="font-serif text-2xl font-bold text-charcoal-900">Hive Home</h1>
          </div>
          <p className="text-xs text-gray-400 uppercase tracking-widest pl-1">Find clarity in chaos</p>
        </div>

        {userPrefs && (
          <div className="px-8 py-6 bg-brand-50/50 hidden md:block border-b border-gray-50">
            <p className="text-xs font-bold text-brand-400 uppercase mb-2">Current Project</p>
            <p className="font-serif font-bold text-charcoal-900 text-lg truncate">{userPrefs.location} Haven</p>
            <p className="text-xs text-gray-500 mt-1">{userPrefs.budgetTier} • {userPrefs.layoutType}</p>
            <div className="flex gap-2 mt-3">
               <span className="px-2 py-1 bg-white rounded text-xs font-medium text-gray-600 border border-gray-200 shadow-sm">{userPrefs.quizAnswers.style.split(' ')[0]}</span>
            </div>
          </div>
        )}

        <nav className="flex-1 flex md:flex-col justify-around md:justify-start p-2 md:p-6 gap-2">
          <button 
            onClick={() => setActiveTab(DashboardTab.VISUALIZER)}
            className={`flex items-center gap-3 px-4 py-4 rounded-xl transition-all ${activeTab === DashboardTab.VISUALIZER ? 'bg-brand-600 text-white shadow-lg shadow-brand-200' : 'text-gray-500 hover:bg-gray-50 hover:text-brand-700'}`}
          >
            <Eye className="w-5 h-5" />
            <span className="hidden md:inline font-medium">Visual Plan</span>
            <span className="md:hidden text-xs">Plan</span>
          </button>

          <button 
            onClick={() => setActiveTab(DashboardTab.MARKETPLACE)}
            className={`flex items-center gap-3 px-4 py-4 rounded-xl transition-all ${activeTab === DashboardTab.MARKETPLACE ? 'bg-brand-600 text-white shadow-lg shadow-brand-200' : 'text-gray-500 hover:bg-gray-50 hover:text-brand-700'}`}
          >
            <ShoppingCart className="w-5 h-5" />
            <span className="hidden md:inline font-medium">Marketplace</span>
            <span className="md:hidden text-xs">Shop</span>
          </button>
        </nav>

        <div className="p-6 hidden md:block border-t border-gray-50">
          <button onClick={handleLogout} className="flex items-center gap-3 text-gray-400 hover:text-red-500 transition-colors text-sm font-medium w-full px-4 py-2 hover:bg-red-50 rounded-lg">
            <LogOut className="w-4 h-4" /> Exit Project
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-4 md:p-10 h-[calc(100vh-80px)] md:h-screen overflow-hidden pb-24 md:pb-10">
        <div className="max-w-7xl mx-auto h-full">
          {userPrefs && (
            <>
              {activeTab === DashboardTab.VISUALIZER && <Visualizer prefs={userPrefs} />}
              {activeTab === DashboardTab.MARKETPLACE && <Marketplace prefs={userPrefs} />}
            </>
          )}
        </div>
      </main>
    </div>
  );
};

export default App;