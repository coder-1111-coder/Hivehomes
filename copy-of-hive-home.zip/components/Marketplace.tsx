import React from 'react';
import { UserPreferences, ProductItem } from '../types';
import { ShoppingBag, MapPin, ExternalLink, Hammer, Phone } from 'lucide-react';

interface MarketplaceProps {
  prefs: UserPreferences;
}

// Hyper-local mock data
const PRODUCTS: ProductItem[] = [
  { id: '1', name: 'Compact Fabric Sofa', price: '₹25,000', category: 'Living', store: 'WoodenStreet', location: 'Indiranagar', imageUrl: 'https://images.unsplash.com/photo-1550254478-ead40cc54513?auto=format&fit=crop&w=300&q=80' },
  { id: '2', name: 'Royale Health Shield Paint', price: '₹650/L', category: 'Supplies', store: 'Local Hardware', location: 'HSR Layout', imageUrl: 'https://images.unsplash.com/photo-1562663474-6cbb3eaa4d14?auto=format&fit=crop&w=300&q=80' },
  { id: '3', name: 'Sheesham Bed (Queen)', price: '₹18,500', category: 'Bedroom', store: 'Wakefit', location: 'Online / Bangalore', imageUrl: 'https://images.unsplash.com/photo-1505693452965-3eeb203fd682?auto=format&fit=crop&w=300&q=80' },
  { id: '4', name: 'Geometric Rug', price: '₹3,200', category: 'Decor', store: 'Home Centre', location: 'Phoenix Marketcity', imageUrl: 'https://images.unsplash.com/photo-1575414003502-9427405d1775?auto=format&fit=crop&w=300&q=80' },
];

export const Marketplace: React.FC<MarketplaceProps> = ({ prefs }) => {
  return (
    <div className="h-full flex flex-col">
      <div className="mb-8">
        <h2 className="text-3xl font-serif font-bold text-charcoal-900">Bring the Plan to Life</h2>
        <p className="text-gray-500">Local Bangalore partners matching your <strong>{prefs.budgetTier}</strong> budget.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {PRODUCTS.map(product => (
          <div key={product.id} className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden hover:shadow-md transition-shadow group">
            <div className="h-48 overflow-hidden relative">
              <img src={product.imageUrl} alt={product.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute top-2 right-2 bg-white/90 backdrop-blur-sm text-xs font-bold px-2 py-1 rounded text-charcoal-800 shadow-sm">
                {product.price}
              </div>
            </div>
            <div className="p-4">
              <h3 className="font-bold text-charcoal-900 text-md truncate">{product.name}</h3>
              <p className="text-xs text-gray-500 mb-4">{product.category}</p>
              
              <div className="flex items-center gap-1 text-gray-500 text-xs mb-4">
                 <MapPin className="w-3 h-3" /> {product.store}, {product.location}
              </div>

              <button className="w-full bg-brand-50 text-brand-700 py-2 rounded-lg text-sm font-bold hover:bg-brand-100 flex items-center justify-center gap-2 transition-colors">
                <ShoppingBag className="w-4 h-4" /> View Details
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Service Connect Section */}
      <div className="mt-auto bg-charcoal-800 text-white rounded-2xl p-8 flex flex-col md:flex-row items-center justify-between gap-6 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-white opacity-5 rounded-full -mr-16 -mt-16"></div>
        
        <div className="relative z-10">
          <h3 className="font-serif text-2xl font-bold mb-2">Need a Reliable Carpenter?</h3>
          <p className="text-gray-300 max-w-md">Don't risk it with unverified labor. Connect with our vetted partner network in Bangalore for installation.</p>
        </div>
        
        <div className="flex gap-4 relative z-10">
           <button className="bg-brand-500 text-white px-6 py-3 rounded-xl font-bold hover:bg-brand-600 transition-colors flex items-center gap-2 shadow-lg">
             <Hammer className="w-4 h-4" /> Find Labor
           </button>
           <button className="bg-white text-charcoal-900 px-6 py-3 rounded-xl font-bold hover:bg-gray-100 transition-colors flex items-center gap-2 shadow-lg">
             <Phone className="w-4 h-4" /> Talk to Expert
           </button>
        </div>
      </div>
    </div>
  );
};