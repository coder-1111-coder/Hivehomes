import React, { useState, useEffect } from 'react';
import { UserPreferences, QuizAnswers } from '../types';
import { ArrowRight, Upload, Check, Home, Shield, Heart, Sparkles, MapPin, CheckCircle2 } from 'lucide-react';

interface OnboardingProps {
  onComplete: (prefs: UserPreferences) => void;
}

const STYLES = [
  { id: 'modern_indian', label: 'Modern Indian Contemporary', desc: 'Clean lines mixed with traditional prints and warm wood tones.', img: 'https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?q=80&w=400&auto=format&fit=crop' },
  { id: 'minimalist', label: 'Minimalist & Functional', desc: 'Clutter-free, neutral colors, focuses on utility. Great for compact flats.', img: 'https://images.unsplash.com/photo-1594026112284-02bb6f3352fe?q=80&w=400&auto=format&fit=crop' },
  { id: 'boho', label: 'Bohemian Desi Chic', desc: 'Vibrant colors, layered textures, jute rugs, relaxed vibe.', img: 'https://images.unsplash.com/photo-1583847268964-b28dc8f51f92?q=80&w=400&auto=format&fit=crop' },
  { id: 'traditional', label: 'Traditional Warmth', desc: 'Darker wood furniture, rich colors like mustard/red, brass accents.', img: 'https://images.unsplash.com/photo-1615529182904-14819c35db37?q=80&w=400&auto=format&fit=crop' },
  { id: 'earthy', label: 'Earthy & Sustainable', desc: 'Terracotta tones, cane furniture, cotton fabrics, lots of plants.', img: 'https://images.unsplash.com/photo-1505693314120-0d443867891c?q=80&w=400&auto=format&fit=crop' },
  { id: 'industrial', label: 'Industrial Budget', desc: 'Exposed shelving, metal accents, cooler color palette.', img: 'https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=400&auto=format&fit=crop' },
];

const BUDGET_TIERS = [
  { id: 'Tier 1', label: 'The Basics (Under ₹2L)', desc: 'Essential painting, basic lighting, loose furniture.' },
  { id: 'Tier 2', label: 'Mid-Range Comfort (₹2L - ₹5L)', desc: 'Modular kitchen basics, wardrobes in one room, better furnishings.' },
  { id: 'Tier 3', label: 'Premium Economy (₹5L - ₹8L)', desc: 'Full modular solutions, false ceiling, wallpaper accents.' },
  { id: 'Tier 4', label: 'The Works (₹8L+)', desc: 'Comprehensive interior design with premium finishes.' },
];

export const Onboarding: React.FC<OnboardingProps> = ({ onComplete }) => {
  const [view, setView] = useState<'HERO' | 'FORM'>('HERO');
  const [step, setStep] = useState(1);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadComplete, setUploadComplete] = useState(false);

  const [formData, setFormData] = useState<UserPreferences>({
    location: 'Whitefield',
    layoutType: 'Compact 2BHK',
    layoutImage: null,
    budgetTier: 'Tier 2',
    familySetup: 'Couple',
    vastuPreference: 'Basic',
    quizAnswers: {
      style: '',
      modularNeeds: []
    }
  });

  const update = (field: keyof UserPreferences, value: any) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const toggleModular = (item: string) => {
    setFormData(prev => {
      const current = prev.quizAnswers.modularNeeds;
      const updated = current.includes(item) ? current.filter(i => i !== item) : [...current, item];
      return { ...prev, quizAnswers: { ...prev.quizAnswers, modularNeeds: updated } };
    });
  };

  const simulateUpload = () => {
    setIsUploading(true);
    setTimeout(() => {
      setIsUploading(false);
      setUploadComplete(true);
      // Simulate file object
      update('layoutImage', new File([""], "Layout_18x30_GrdFloor.jpg"));
    }, 2000);
  };

  const next = () => setStep(s => s + 1);
  const back = () => setStep(s => s - 1);

  // --- Views ---

  if (view === 'HERO') {
    return (
      <div className="min-h-screen bg-warm-50 flex flex-col items-center justify-center p-6 text-center relative overflow-hidden">
        {/* Abstract Background Shapes */}
        <div className="absolute top-0 left-0 w-64 h-64 bg-brand-100 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2 opacity-50"></div>
        <div className="absolute bottom-0 right-0 w-96 h-96 bg-brand-200 rounded-full blur-3xl translate-x-1/3 translate-y-1/3 opacity-50"></div>

        <div className="z-10 max-w-3xl space-y-8 animate-fade-in">
          <div className="inline-block p-3 rounded-full bg-brand-50 border border-brand-100 mb-4 shadow-sm">
             <Sparkles className="w-6 h-6 text-brand-500" />
          </div>
          <h1 className="font-serif text-5xl md:text-7xl font-bold text-brand-800 tracking-tight leading-tight">
            Hive Home
          </h1>
          <p className="text-xl md:text-2xl text-brand-600 font-serif italic">
            "Find clarity in chaos"
          </p>
          <h2 className="text-charcoal-800 text-lg md:text-xl font-medium mt-6">
            Just bought a home in Namma Bengaluru but don't know where to start?
          </h2>
          <p className="text-gray-500 leading-relaxed max-w-xl mx-auto">
            Get a personalized, budget-friendly design plan without expensive designers. Visualise before you buy.
          </p>
          
          <button 
            onClick={() => setView('FORM')}
            className="group bg-brand-600 text-white px-10 py-4 rounded-full text-lg font-medium shadow-xl shadow-brand-200 hover:bg-brand-700 hover:scale-105 transition-all flex items-center gap-3 mx-auto mt-8"
          >
            Start My Home Journey (Free) <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-warm-50 flex items-center justify-center p-4">
      <div className="w-full max-w-5xl bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row min-h-[600px] animate-fade-in">
        
        {/* Sidebar / Progress */}
        <div className="bg-brand-50 w-full md:w-1/3 p-8 flex flex-col justify-between border-r border-brand-100">
          <div>
            <h2 className="font-serif text-2xl font-bold text-brand-800 mb-2">The Deep Dive</h2>
            <p className="text-sm text-brand-600 mb-8">Building your budget-friendly profile.</p>
            
            <div className="space-y-6">
              {[
                { n: 1, title: "Location & Layout", icon: MapPin },
                { n: 2, title: "Realistic Budget", icon: Shield },
                { n: 3, title: "Functional Needs", icon: Home },
                { n: 4, title: "Aesthetic Vibe", icon: Sparkles }
              ].map((item) => (
                <div key={item.n} className={`flex items-center gap-4 transition-colors ${step === item.n ? 'text-brand-800' : 'text-gray-400'}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold border-2 ${step === item.n ? 'border-brand-600 bg-brand-600 text-white' : 'border-gray-200 bg-white'}`}>
                    {step > item.n ? <Check className="w-4 h-4" /> : item.n}
                  </div>
                  <span className={`font-medium ${step === item.n ? 'font-bold' : ''}`}>{item.title}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="mt-8 bg-white p-4 rounded-xl border border-brand-100 shadow-sm">
             <div className="flex items-center gap-2 mb-2">
               <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
               <span className="text-xs font-bold text-gray-500 uppercase">Live Context</span>
             </div>
             <p className="text-xs text-brand-800">
               Prices and recommendations are currently calibrated for <strong>Bangalore Market Rates (2025)</strong>.
             </p>
          </div>
        </div>

        {/* Form Content */}
        <div className="flex-1 p-8 md:p-12 overflow-y-auto">
          {step === 1 && (
            <div className="space-y-8 animate-fade-in">
              <h3 className="text-2xl font-serif font-bold text-charcoal-900">Let's map your space</h3>
              
              <div className="grid grid-cols-2 gap-4">
                 <div>
                    <label className="block text-sm font-bold text-gray-600 mb-2">Bangalore Location</label>
                    <select className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-500 outline-none"
                      value={formData.location}
                      onChange={(e) => update('location', e.target.value)}
                    >
                      <option>Whitefield</option>
                      <option>Electronic City</option>
                      <option>HSR Layout</option>
                      <option>Indiranagar</option>
                      <option>Yelahanka</option>
                      <option>Jayanagar</option>
                      <option>Koramangala</option>
                      <option>Hebbal</option>
                    </select>
                 </div>
                 <div>
                    <label className="block text-sm font-bold text-gray-600 mb-2">Layout Type</label>
                    <select className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 focus:ring-2 focus:ring-brand-500 outline-none"
                      value={formData.layoutType}
                      onChange={(e) => update('layoutType', e.target.value)}
                    >
                      <option>1BHK</option>
                      <option>Compact 2BHK</option>
                      <option>Standard 2BHK</option>
                      <option>3BHK</option>
                    </select>
                 </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-600 mb-2">Floor Plan</label>
                {!uploadComplete ? (
                  <div 
                    onClick={simulateUpload}
                    className="border-2 border-dashed border-gray-200 rounded-xl p-8 flex flex-col items-center justify-center text-center hover:bg-brand-50 hover:border-brand-300 transition-colors cursor-pointer relative h-48"
                  >
                    {isUploading ? (
                      <div className="flex flex-col items-center">
                        <div className="w-8 h-8 border-4 border-brand-200 border-t-brand-600 rounded-full animate-spin mb-3"></div>
                        <span className="text-brand-600 font-bold text-sm">Analyzing walls & windows...</span>
                      </div>
                    ) : (
                      <>
                        <div className="bg-brand-100 p-3 rounded-full mb-3">
                          <Upload className="w-6 h-6 text-brand-600" />
                        </div>
                        <p className="font-medium text-gray-700">Click to Simulate Upload</p>
                        <p className="text-xs text-gray-400 mt-1">We'll use a sample 18x30 ground floor plan.</p>
                      </>
                    )}
                  </div>
                ) : (
                  <div className="bg-green-50 border border-green-200 rounded-xl p-4 flex items-center gap-3">
                    <CheckCircle2 className="w-6 h-6 text-green-600" />
                    <div>
                      <p className="font-bold text-green-800 text-sm">Layout_18x30_GrdFloor.jpg</p>
                      <p className="text-xs text-green-600">Successfully analyzed 4 rooms.</p>
                    </div>
                    <button onClick={() => setUploadComplete(false)} className="ml-auto text-xs underline text-green-700">Change</button>
                  </div>
                )}
              </div>

              <button 
                onClick={next} 
                disabled={!uploadComplete}
                className="w-full bg-brand-600 text-white py-4 rounded-xl font-bold hover:bg-brand-700 transition-all flex justify-center items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Next Step <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-8 animate-fade-in">
              <div>
                <h3 className="text-2xl font-serif font-bold text-charcoal-900">Define your budget</h3>
                <p className="text-gray-500 mt-1">Select a realistic tier based on Bangalore market rates.</p>
              </div>

              <div className="space-y-3">
                 {BUDGET_TIERS.map(tier => (
                   <button 
                    key={tier.id}
                    onClick={() => update('budgetTier', tier.id)}
                    className={`w-full text-left p-4 rounded-xl border-2 transition-all group hover:border-brand-300 ${formData.budgetTier === tier.id ? 'border-brand-500 bg-brand-50 ring-1 ring-brand-500' : 'border-gray-100'}`}
                   >
                     <div className="flex justify-between items-center mb-1">
                       <span className={`font-bold ${formData.budgetTier === tier.id ? 'text-brand-900' : 'text-gray-700'}`}>{tier.label}</span>
                       {formData.budgetTier === tier.id && <CheckCircle2 className="w-5 h-5 text-brand-600" />}
                     </div>
                     <p className="text-sm text-gray-500 group-hover:text-gray-600">{tier.desc}</p>
                   </button>
                 ))}
              </div>

              <div className="flex gap-4">
                <button onClick={back} className="flex-1 bg-gray-100 text-gray-600 py-4 rounded-xl font-bold hover:bg-gray-200">Back</button>
                <button onClick={next} className="flex-[2] bg-brand-600 text-white py-4 rounded-xl font-bold hover:bg-brand-700">Next Step</button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-8 animate-fade-in">
              <h3 className="text-2xl font-serif font-bold text-charcoal-900">Functionality & Beliefs</h3>

              <div>
                <label className="block text-sm font-bold text-gray-600 mb-3">Looking for Modular Solutions?</label>
                <div className="grid grid-cols-2 gap-3">
                  {['Modular Kitchen', 'Wardrobes', 'TV Unit', 'Shoe Rack'].map(item => (
                    <button 
                      key={item}
                      onClick={() => toggleModular(item)}
                      className={`p-3 rounded-xl border text-sm font-medium transition-all flex items-center gap-2 ${formData.quizAnswers.modularNeeds.includes(item) ? 'bg-brand-50 border-brand-500 text-brand-800' : 'border-gray-200 text-gray-500'}`}
                    >
                      <div className={`w-4 h-4 rounded border flex items-center justify-center ${formData.quizAnswers.modularNeeds.includes(item) ? 'bg-brand-500 border-brand-500' : 'border-gray-300'}`}>
                        {formData.quizAnswers.modularNeeds.includes(item) && <Check className="w-3 h-3 text-white" />}
                      </div>
                      {item}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-600 mb-3">Family Setup</label>
                  <select 
                    className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 outline-none"
                    value={formData.familySetup}
                    onChange={(e) => update('familySetup', e.target.value)}
                  >
                    <option>Couple</option>
                    <option>Family with Kids</option>
                    <option>Multi-generational</option>
                  </select>
                </div>
                <div>
                   <label className="block text-sm font-bold text-gray-600 mb-3">Vastu Preference</label>
                   <select 
                    className="w-full p-3 bg-gray-50 rounded-xl border border-gray-200 outline-none"
                    value={formData.vastuPreference}
                    onChange={(e) => update('vastuPreference', e.target.value)}
                  >
                    <option>Strict</option>
                    <option>Basic</option>
                    <option>None</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-4">
                <button onClick={back} className="flex-1 bg-gray-100 text-gray-600 py-4 rounded-xl font-bold hover:bg-gray-200">Back</button>
                <button onClick={next} className="flex-[2] bg-brand-600 text-white py-4 rounded-xl font-bold hover:bg-brand-700">Next Step</button>
              </div>
            </div>
          )}

          {step === 4 && (
            <div className="space-y-6 animate-fade-in">
              <h3 className="text-2xl font-serif font-bold text-charcoal-900">Your Aesthetic Vibe</h3>

              <div className="grid grid-cols-2 gap-4">
                {STYLES.map(s => (
                  <div 
                    key={s.id} 
                    onClick={() => {
                      setFormData(prev => ({ ...prev, quizAnswers: { ...prev.quizAnswers, style: s.label } }));
                    }}
                    className={`relative rounded-xl overflow-hidden cursor-pointer group border-2 transition-all ${formData.quizAnswers.style === s.label ? 'border-brand-500 ring-2 ring-brand-200' : 'border-transparent hover:border-gray-200'}`}
                  >
                    <img src={s.img} alt={s.label} className="w-full h-32 object-cover transition-transform group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent flex flex-col justify-end p-3">
                      <span className="text-white font-bold text-sm leading-tight">{s.label}</span>
                      <span className="text-gray-300 text-xs mt-1 leading-tight">{s.desc}</span>
                    </div>
                    {formData.quizAnswers.style === s.label && (
                      <div className="absolute top-2 right-2 bg-brand-500 text-white rounded-full p-1">
                        <Check className="w-3 h-3" />
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <button 
                onClick={() => onComplete(formData)} 
                disabled={!formData.quizAnswers.style}
                className="w-full bg-brand-800 text-white py-4 rounded-xl font-bold shadow-lg hover:bg-brand-900 transition-all flex justify-center items-center gap-2 mt-4 disabled:opacity-50"
              >
                Generate My Hive Plan <Sparkles className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};