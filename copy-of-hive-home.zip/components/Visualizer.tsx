import React, { useState, useEffect } from 'react';
import { UserPreferences } from '../types';
import { generateDesignAdvice } from '../services/geminiService';
import { Sparkles, RefreshCw, Palette, Armchair, Home, Loader2, Eye, Info } from 'lucide-react';
import ReactMarkdown from 'react-markdown';

interface VisualizerProps {
  prefs: UserPreferences;
}

const ROOMS = ['Living Area', 'Kitchen', 'Master Bedroom'];

export const Visualizer: React.FC<VisualizerProps> = ({ prefs }) => {
  const [activeRoom, setActiveRoom] = useState('Living Area');
  const [loading, setLoading] = useState(true);
  const [advice, setAdvice] = useState('');
  
  // Visualizer State
  const [viewMode, setViewMode] = useState<'BASE' | 'HIVE'>('HIVE');
  const [overlayColor, setOverlayColor] = useState('Terracotta');

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      const text = await generateDesignAdvice(prefs);
      setAdvice(text);
      setLoading(false);
    };
    fetch();
  }, []);

  // Placeholders specifically describing middle class homes
  const getRoomImage = (room: string) => {
    // Living Area: Grey sofa, rug, standard apartment look
    if (room === 'Living Area') return "https://images.unsplash.com/photo-1550581190-9c1c48d21d6c?q=80&w=800&auto=format&fit=crop"; 
    // Master Bedroom: Bed with wardrobe/storage visible
    if (room === 'Master Bedroom') return "https://images.unsplash.com/photo-1595526114035-0d45ed16cfbf?q=80&w=800&auto=format&fit=crop";
    // Kitchen: Modular setup - Updated Image
    return "https://images.unsplash.com/photo-1588854337444-688dd516d299?q=80&w=800&auto=format&fit=crop"; 
  };

  const currentImage = getRoomImage(activeRoom);

  // Simulation description based on room and state
  const getSimulationText = () => {
    if (viewMode === 'BASE') {
      return `Original ${activeRoom}: Standard builder-grade finish. Mosaic/Ceramic tile flooring, white wash walls, single tube-light point. Empty space.`;
    }
    
    // Hive Mode descriptions
    if (activeRoom === 'Living Area') {
      return `Simulation: A standard middle-class Bangalore living room showing mosaic tile flooring. The overlay shows the wall painted in 'Warm ${overlayColor}' (Asian Paints), a grey 3-seater budget sofa placed against the long wall, and a jute rug covering the center floor area.`;
    }
    if (activeRoom === 'Kitchen') {
      return `Simulation: L-shaped Modular layout. Base cabinets in 'Frosty White' laminate with edge banding. Granite countertop retained. Overhead storage added for spice jars.`;
    }
    return `Simulation: Queen size bed placed South-North. ${overlayColor} accent wall behind the headboard. Modular sliding wardrobe in white finish to save space.`;
  };

  if (loading) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-center p-8">
        <div className="w-16 h-16 border-4 border-brand-200 border-t-brand-600 rounded-full animate-spin mb-6"></div>
        <h3 className="text-2xl font-serif font-bold text-charcoal-800">Structuring your Hive Plan...</h3>
        <p className="text-gray-500 mt-2">Analyzing 18x30 Layout Plan...</p>
        <p className="text-xs text-gray-400 mt-1">Calibrating for {prefs.budgetTier}...</p>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col gap-6">
      {/* Room Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-2 border-b border-gray-100">
        {ROOMS.map(room => (
          <button
            key={room}
            onClick={() => setActiveRoom(room)}
            className={`px-6 py-3 rounded-t-xl font-bold transition-all whitespace-nowrap ${activeRoom === room ? 'bg-brand-50 text-brand-800 border-b-2 border-brand-500' : 'text-gray-500 hover:text-gray-800 hover:bg-gray-50'}`}
          >
            {room}
          </button>
        ))}
      </div>

      <div className="flex flex-col lg:flex-row gap-8 h-full overflow-y-auto">
        {/* Left: Amazon AR Simulator */}
        <div className="flex-[3] flex flex-col gap-4">
           
           <div className="flex justify-between items-center">
             <h3 className="font-bold text-charcoal-900 flex items-center gap-2">
               <Eye className="w-5 h-5 text-brand-600" /> Visualise It: Your {activeRoom}
             </h3>
             <div className="flex bg-gray-100 p-1 rounded-lg">
                <button 
                  onClick={() => setViewMode('BASE')}
                  className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${viewMode === 'BASE' ? 'bg-white shadow text-gray-800' : 'text-gray-500'}`}
                >
                  Base Room
                </button>
                <button 
                  onClick={() => setViewMode('HIVE')}
                  className={`px-3 py-1 text-xs font-bold rounded-md transition-all ${viewMode === 'HIVE' ? 'bg-brand-600 shadow text-white' : 'text-gray-500'}`}
                >
                  Hive Design
                </button>
             </div>
           </div>

           <div className="relative rounded-2xl overflow-hidden bg-gray-900 h-[400px] shadow-lg group border-4 border-white">
              <img 
                src={currentImage} 
                alt={activeRoom} 
                className={`w-full h-full object-cover transition-all duration-700 ${viewMode === 'BASE' ? 'grayscale opacity-80' : 'grayscale-0 opacity-100'}`} 
              />
              
              {/* Simulation Text Overlay - "AR Effect" */}
              <div className="absolute bottom-0 inset-x-0 bg-black/70 backdrop-blur-md p-4 border-t border-white/10">
                 <p className="text-white text-sm font-medium leading-relaxed">
                   <Info className="w-4 h-4 inline mr-2 text-brand-400" />
                   {getSimulationText()}
                 </p>
              </div>

              {/* Tags visible only in Hive Mode */}
              {viewMode === 'HIVE' && (
                <>
                  <div className="absolute top-1/2 left-1/3 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-brand-800 shadow-sm animate-fade-in">
                    <Palette className="w-3 h-3 inline mr-1" /> {overlayColor} Wall
                  </div>
                  <div className="absolute bottom-1/3 right-1/4 bg-white/90 backdrop-blur px-3 py-1 rounded-full text-xs font-bold text-brand-800 shadow-sm animate-fade-in delay-100">
                    <Armchair className="w-3 h-3 inline mr-1" /> {prefs.quizAnswers.style.split(' ')[0]} Sofa
                  </div>
                </>
              )}
           </div>

           {/* Interactive Controls */}
           {viewMode === 'HIVE' && (
             <div className="bg-white p-4 rounded-xl border border-gray-200 flex flex-wrap gap-4 items-center justify-between shadow-sm animate-fade-in">
                <div className="flex items-center gap-3">
                   <span className="text-xs font-bold text-gray-500 uppercase tracking-wide">Try Wall Colors:</span>
                   {['Terracotta', 'Sage', 'Beige', 'Grey'].map(c => (
                     <button 
                      key={c}
                      onClick={() => setOverlayColor(c)} 
                      className={`px-3 py-1 rounded border text-xs font-medium ${overlayColor === c ? 'bg-gray-800 text-white border-gray-800' : 'bg-white text-gray-600 border-gray-300'}`}
                     >
                       {c}
                     </button>
                   ))}
                </div>
                <button className="flex items-center gap-2 text-xs font-bold text-brand-600 hover:text-brand-800">
                  <RefreshCw className="w-3 h-3" /> Swap Furniture
                </button>
             </div>
           )}
        </div>

        {/* Right: Design Plan */}
        <div className="flex-[2] bg-brand-50/50 rounded-2xl p-6 border border-brand-100 overflow-y-auto max-h-[550px]">
           <h3 className="font-serif font-bold text-xl text-brand-900 mb-4 flex items-center gap-2">
             <Home className="w-5 h-5" /> {activeRoom} Plan
           </h3>
           
           <div className="prose prose-sm prose-brand mb-6">
             <ReactMarkdown components={{
               h1: ({node, ...props}) => <h3 className="text-lg font-bold text-brand-800 mt-4 mb-2 border-b border-brand-200 pb-1" {...props} />,
               h2: ({node, ...props}) => <h3 className="text-lg font-bold text-brand-800 mt-4 mb-2 border-b border-brand-200 pb-1" {...props} />,
               strong: ({node, ...props}) => <span className="font-bold text-brand-700" {...props} />,
               ul: ({node, ...props}) => <ul className="space-y-2 list-disc pl-4 text-gray-700" {...props} />
             }}>
               {advice}
             </ReactMarkdown>
           </div>

           {/* Budget Checklist Card */}
           <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm">
             <p className="text-xs font-bold text-gray-400 uppercase mb-3">Checklist for {prefs.budgetTier}</p>
             <ul className="space-y-2">
               <li className="flex items-center gap-2 text-sm text-gray-700">
                 <div className="w-4 h-4 rounded border border-gray-300"></div> Accent Wall Painting (Self or Local Painter)
               </li>
               <li className="flex items-center gap-2 text-sm text-gray-700">
                 <div className="w-4 h-4 rounded border border-gray-300"></div> {activeRoom === 'Living Area' ? 'Modular TV Unit (Engineered Wood)' : '3-Door Wardrobe (Non-soft close)'}
               </li>
               <li className="flex items-center gap-2 text-sm text-gray-700">
                 <div className="w-4 h-4 rounded border border-gray-300"></div> Basic Curtains & Rods
               </li>
             </ul>
           </div>
        </div>
      </div>
    </div>
  );
};