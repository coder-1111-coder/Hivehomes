import { GoogleGenAI } from "@google/genai";
import { UserPreferences } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const generateDesignAdvice = async (prefs: UserPreferences): Promise<string> => {
  const modelId = 'gemini-3-flash-preview'; 
  
  // Backup advice in case AI fails
  const fallbackAdvice = `
## Living Room
**Layout Strategy:** Arrange the L-shaped sofa against the solid wall to face the TV unit. Ensure clear walkway to the balcony.
**Color & Materials:** Use a 'Warm Terracotta' accent wall with neutral beige on other walls. Choose stain-resistant polyester fabric for the sofa.
**Smart Tip:** For a ${prefs.budgetTier} budget, use modular TV units with laminate finish instead of solid wood.

## Kitchen
**Layout Strategy:** L-shaped counter utilization. Place the fridge near the entrance for easy access.
**Color & Materials:** High-gloss laminate shutters in dual tone (White & Wood).
**Smart Tip:** Use tandem boxes for heavy utensils to maximize storage in compact spaces.

## Master Bedroom
**Layout Strategy:** Wardrobe on the West wall for insulation. Bed headboard against the South wall (Vastu friendly).
**Color & Materials:** Calming sage green accent wall. 
**Smart Tip:** A hydraulic bed offers 20% more storage for linens and blankets.
`;

  const prompt = `
    You are the Senior Design Lead for "Hive Home", an app for middle-class homeowners in Bangalore, India.
    Your tone is reassuring, practical, and culturally aware.
    
    **User Profile:**
    - Location: ${prefs.location}, Bangalore.
    - Layout: ${prefs.layoutType} (Sample 18x30 Plan).
    - Budget Tier: ${prefs.budgetTier}.
    - Family: ${prefs.familySetup}.
    - Vastu: ${prefs.vastuPreference}.
    - Modular Needs: ${prefs.quizAnswers.modularNeeds.join(", ") || "None"}.
    - Style: ${prefs.quizAnswers.style}.

    Generate a "Visual Plan" summary for 3 rooms: **Living Room**, **Kitchen**, and **Master Bedroom**.
    For each room, provide:
    1. **Layout Strategy**: Furniture placement (mentioning Vastu if strict/basic).
    2. **Color & Materials**: Specific colors (e.g., Asian Paints names) and materials (e.g., Ply vs MDF, laminate types) suitable for the Bangalore climate (dust/weather) and their budget.
    3. **Smart Tip**: A specific money-saving or functionality tip based on their profile (e.g., "Use granite instead of quartz for durability" or "Use wallpapers instead of texture paint").

    Format strictly in Markdown. Keep it concise.
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
    });
    return response.text || fallbackAdvice;
  } catch (error) {
    console.error("Gemini API Error:", error);
    return fallbackAdvice;
  }
};