export enum AppView {
  ONBOARDING = 'ONBOARDING',
  DASHBOARD = 'DASHBOARD',
}

export enum DashboardTab {
  VISUALIZER = 'VISUALIZER',
  MARKETPLACE = 'MARKETPLACE',
}

export interface QuizAnswers {
  style: string;
  modularNeeds: string[]; // Array of selected modular items
}

export interface UserPreferences {
  // Step 1: House
  location: string;
  layoutType: '1BHK' | 'Compact 2BHK' | 'Standard 2BHK' | '3BHK';
  layoutImage: File | null; // Placeholder for the 18x30 plan

  // Step 2: Realistic Budget
  budgetTier: 'Tier 1' | 'Tier 2' | 'Tier 3' | 'Tier 4';

  // Step 3: Functional & Family
  familySetup: 'Couple' | 'Family with Kids' | 'Multi-generational';
  vastuPreference: 'Strict' | 'Basic' | 'None';
  
  // Step 4: Aesthetics
  quizAnswers: QuizAnswers;
}

export interface ProductItem {
  id: string;
  name: string;
  price: string;
  category: string;
  store: string;
  location: string;
  imageUrl: string;
}